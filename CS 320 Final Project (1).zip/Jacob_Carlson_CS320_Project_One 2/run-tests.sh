#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mkdir -p build/tools build/main build/test reports/junit
repo=https://repo.maven.apache.org/maven2
fetch() {
    local name=$1 artifact=$2 digest=$3
    if [[ ! -f "build/tools/$name" ]]; then
        curl --fail --location --silent --show-error "$repo/$artifact" -o "build/tools/$name"
    fi
    if command -v sha256sum >/dev/null 2>&1; then
        printf '%s  %s\n' "$digest" "build/tools/$name" | sha256sum -c - >/dev/null
    else
        printf '%s  %s\n' "$digest" "build/tools/$name" | shasum -a 256 -c - >/dev/null
    fi
}
fetch junit.jar org/junit/platform/junit-platform-console-standalone/1.10.2/junit-platform-console-standalone-1.10.2.jar a1de557821293ce903c213c694165fff532cf92081bac4238b9e05b35f04f43f
fetch ecj.jar org/eclipse/jdt/ecj/3.37.0/ecj-3.37.0.jar cde026ff966b48b5e5f148b6f041ceff3cf4f85cf75155f4ec0f40e4ee14b545
fetch jacocoagent.jar org/jacoco/org.jacoco.agent/0.8.12/org.jacoco.agent-0.8.12-runtime.jar 115e8e6e6593ca3a9892dfef695df4d487c706e59e71e64dc0ab95716ee02622
fetch jacococli.jar org/jacoco/org.jacoco.cli/0.8.12/org.jacoco.cli-0.8.12-nodeps.jar 594c01125b84864a7fc5a9efab19b71b7de36b27346863f6d7cd0cd45400ceb0
java -jar build/tools/ecj.jar -8 -g -warn:none -d build/main \
    ContactService/Contact.java ContactService/ContactService.java \
    TaskService/Task.java TaskService/TaskService.java \
    AppointmentService/Appointment.java AppointmentService/AppointmentService.java
java -jar build/tools/ecj.jar -8 -g -warn:none -cp "build/main:build/tools/junit.jar" -d build/test \
    ContactService/ContactTest.java ContactService/ContactServiceTest.java \
    TaskService/TaskTest.java TaskService/TaskServiceTest.java \
    AppointmentService/AppointmentTest.java AppointmentService/AppointmentServiceTest.java
java -javaagent:build/tools/jacocoagent.jar=destfile=build/jacoco.exec,append=false \
    -jar build/tools/junit.jar execute --class-path build/main:build/test \
    --scan-class-path --fail-if-no-tests --reports-dir reports/junit \
    --details summary --disable-ansi-colors | tee reports/test-results.txt
java -jar build/tools/jacococli.jar report build/jacoco.exec --classfiles build/main \
    --sourcefiles ContactService --sourcefiles TaskService --sourcefiles AppointmentService \
    --html reports/coverage --xml reports/coverage.xml --csv reports/coverage.csv
awk -F, 'NR > 1 { total = $8 + $9; if (total == 0 || $9 / total < 0.80) { print "Coverage below 80% for " $3; exit 1 } }' reports/coverage.csv
printf '%s\n' 'Coverage meets 80% for every application class. Open reports/coverage/index.html for details.'
