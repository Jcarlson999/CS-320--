Jacob Carlson
CS 320 Project One

CONTENTS
ContactService: Contact.java, ContactService.java, ContactTest.java, ContactServiceTest.java
TaskService: Task.java, TaskService.java, TaskTest.java, TaskServiceTest.java
AppointmentService: Appointment.java, AppointmentService.java, AppointmentTest.java, AppointmentServiceTest.java

All data stays in memory. No database, UI, or main method is required.
IDs are permanent. Services enforce uniqueness within their own stored records.
Invalid input, duplicate IDs, and unknown IDs throw IllegalArgumentException.
Rejected edits leave the original field value unchanged.
Appointment uses java.util.Date and before(new Date()) as required, with defensive
copies to prevent mutation through a caller-owned Date.

RUN IN ECLIPSE OR CODIO
1. Create a Java project and add all 12 Java files to the source folder.
   The files use the default package, so do not add package declarations.
2. Add JUnit 5 to the project's build path.
3. Select the project and run it as a JUnit test.
4. For Eclipse coverage, use Coverage As > JUnit Test if EclEmma is installed.

REPRODUCE THE INCLUDED REPORTS
On Linux, macOS, or Codio with Bash, Java 17+, curl, and a SHA-256 utility:
    bash run-tests.sh
The script downloads fixed versions of JUnit Platform Console 1.10.2, Eclipse
Compiler 3.37.0, and JaCoCo 0.8.12 from Maven Central and verifies their hashes.
It compiles Java 8-compatible bytecode, runs every test, regenerates the reports,
and fails if any application class has less than 80% line coverage.
Internet access is required for the first run. Downloads and compiled output
are kept in build/ and are excluded from this submission ZIP.

RESULTS
69 tests passed, 0 failed, 0 skipped.
JaCoCo measured 100% line and branch coverage in all six application classes.
Test classes are excluded from the application coverage denominator.
Open reports/coverage/index.html in a browser to inspect the measured coverage.
reports/coverage.csv and reports/coverage.xml contain machine-readable results.
reports/test-results.txt and reports/junit/ contain JUnit execution results.
These reports describe the supplied tests, not a guarantee of defect-free code.

REQUIREMENT MAP
ContactTest: all five fields, nulls, maximum lengths, invalid phone values,
immutable ID, and valid/invalid edits.
ContactServiceTest: add unique IDs, duplicate/null rejection, delete by ID,
update every permitted field, preserve other records, and unknown ID handling.
TaskTest: all three fields, nulls, maximum lengths, immutable ID, and edits.
TaskServiceTest: unique addition, duplicate/null rejection, delete, update name
and description, unchanged state after invalid edits, and unknown IDs.
AppointmentTest: all three fields, nulls, maximum lengths, past/future dates,
immutable ID, and defensive Date copying.
AppointmentServiceTest: unique addition, duplicate/null rejection, deletion,
record isolation, ID reuse after deletion, and unknown IDs.

SOURCE AND FEEDBACK
The Contact implementation and tests carry forward the earlier Contact Service
project. Task and Appointment implementations and tests were added for this
combined project. No instructor feedback was supplied for incorporation.


