import java.util.Date;

/** Validates appointment details and prevents external changes to its Date. */
public final class Appointment {
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID is null or too long");
        }
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date is required");
        }
        // Copy first so validation and storage use the same timestamp.
        Date copiedDate = new Date(appointmentDate.getTime());
        if (copiedDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description is null or too long");
        }
        this.appointmentId = appointmentId;
        this.appointmentDate = copiedDate;
        this.description = description;
    }

    public String getAppointmentId() { return appointmentId; }
    public Date getAppointmentDate() { return new Date(appointmentDate.getTime()); }
    public String getDescription() { return description; }
}
