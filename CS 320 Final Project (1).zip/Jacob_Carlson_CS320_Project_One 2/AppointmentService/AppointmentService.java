import java.util.HashMap;
import java.util.Map;

/** Stores appointments in memory. Appointment updates are outside this service. */
public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {
        if (appointment == null || appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment is null or ID already exists");
        }
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    public Appointment getAppointment(String appointmentId) {
        Appointment appointment = appointments.get(appointmentId);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment ID was not found");
        }
        return appointment;
    }

    public void deleteAppointment(String appointmentId) {
        getAppointment(appointmentId);
        appointments.remove(appointmentId);
    }
}
