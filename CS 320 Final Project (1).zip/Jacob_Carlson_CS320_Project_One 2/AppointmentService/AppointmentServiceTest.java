import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {
    private Appointment appointment(String id) {
        return new Appointment(id, new Date(System.currentTimeMillis() + 86400000L), "Checkup");
    }

    @Test
    void addsUniqueAppointmentsAndPreservesOriginalOnDuplicate() {
        AppointmentService service = new AppointmentService();
        Appointment first = appointment("1");
        Appointment second = appointment("2");
        service.addAppointment(first);
        service.addAppointment(second);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appointment("1")));
        assertSame(first, service.getAppointment("1"));
        assertSame(second, service.getAppointment("2"));
    }

    @Test
    void rejectsNullAppointment() {
        assertThrows(IllegalArgumentException.class,
                     () -> new AppointmentService().addAppointment(null));
    }

    @Test
    void deletesOnlyRequestedIdAndAllowsReuse() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("1"));
        service.addAppointment(appointment("2"));
        service.deleteAppointment("1");
        assertThrows(IllegalArgumentException.class, () -> service.getAppointment("1"));
        assertEquals("2", service.getAppointment("2").getAppointmentId());
        Appointment replacement = appointment("1");
        service.addAppointment(replacement);
        assertSame(replacement, service.getAppointment("1"));
    }

    @Test
    void rejectsMissingAndNullIds() {
        AppointmentService service = new AppointmentService();
        for (String id : new String[] {"missing", null}) {
            assertThrows(IllegalArgumentException.class, () -> service.getAppointment(id));
            assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment(id));
        }
    }
}
