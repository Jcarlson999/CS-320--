import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import java.lang.reflect.Modifier;
import org.junit.jupiter.api.Test;

class AppointmentTest {
    private Date future() { return new Date(System.currentTimeMillis() + 86400000L); }
    private String text(int length) { return new String(new char[length]).replace('\0', 'X'); }

    @Test
    void storesValidAppointmentAtStringLimits() {
        Date date = future();
        Appointment appointment = new Appointment("1234567890", date, text(50));
        assertAll(() -> assertEquals("1234567890", appointment.getAppointmentId()),
                  () -> assertEquals(date, appointment.getAppointmentDate()),
                  () -> assertEquals(text(50), appointment.getDescription()));
    }

    @Test
    void rejectsNullAndOverlongIds() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, future(), "Details"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment(text(11), future(), "Details"));
    }

    @Test
    void rejectsNullDate() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "Details"));
    }

    @Test
    void rejectsDatesInThePast() {
        Date past = new Date(System.currentTimeMillis() - 1000L);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", past, "Details"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", new Date(0), "Details"));
    }

    @Test
    void rejectsNullAndOverlongDescriptions() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future(), null));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", future(), text(51)));
    }

    @Test
    void constructorCopiesDateToPreventExternalMutation() {
        Date date = future();
        long expected = date.getTime();
        Appointment appointment = new Appointment("1", date, "Details");
        date.setTime(0);
        assertEquals(expected, appointment.getAppointmentDate().getTime());
    }

    @Test
    void getterReturnsACopyToPreserveStoredDate() {
        Appointment appointment = new Appointment("1", future(), "Details");
        Date returned = appointment.getAppointmentDate();
        long expected = returned.getTime();
        returned.setTime(0);
        assertEquals(expected, appointment.getAppointmentDate().getTime());
        assertNotSame(appointment.getAppointmentDate(), appointment.getAppointmentDate());
    }

    @Test
    void idIsPrivateFinalAndHasNoSetter() throws Exception {
        int modifiers = Appointment.class.getDeclaredField("appointmentId").getModifiers();
        assertTrue(Modifier.isPrivate(modifiers));
        assertTrue(Modifier.isFinal(modifiers));
        assertThrows(NoSuchMethodException.class,
                     () -> Appointment.class.getMethod("setAppointmentId", String.class));
    }
}
