import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskServiceTest {
    private Task task(String id) { return new Task(id, "Name", "Details"); }

    @Test
    void addsUniqueTasksAndPreservesOriginalOnDuplicate() {
        TaskService service = new TaskService();
        Task first = task("1");
        Task second = task("2");
        service.addTask(first);
        service.addTask(second);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task("1")));
        assertSame(first, service.getTask("1"));
        assertSame(second, service.getTask("2"));
    }

    @Test
    void rejectsNullTask() {
        assertThrows(IllegalArgumentException.class, () -> new TaskService().addTask(null));
    }

    @Test
    void deletesOnlyRequestedIdAndAllowsReuse() {
        TaskService service = new TaskService();
        service.addTask(task("1"));
        service.addTask(task("2"));
        service.deleteTask("1");
        assertThrows(IllegalArgumentException.class, () -> service.getTask("1"));
        assertEquals("2", service.getTask("2").getTaskId());
        Task replacement = task("1");
        service.addTask(replacement);
        assertSame(replacement, service.getTask("1"));
    }

    @Test
    void updatesOnlyTheRequestedTaskAndPreservesItsId() {
        TaskService service = new TaskService();
        service.addTask(task("1"));
        service.addTask(task("2"));
        service.updateName("1", "Changed name");
        service.updateDescription("1", "Changed details");
        assertAll(() -> assertEquals("Changed name", service.getTask("1").getName()),
                  () -> assertEquals("Changed details", service.getTask("1").getDescription()),
                  () -> assertEquals("1", service.getTask("1").getTaskId()),
                  () -> assertEquals("Name", service.getTask("2").getName()),
                  () -> assertEquals("Details", service.getTask("2").getDescription()));
    }

    @Test
    void invalidEditsLeaveStoredTaskUnchanged() {
        TaskService service = new TaskService();
        service.addTask(task("1"));
        assertThrows(IllegalArgumentException.class, () -> service.updateName("1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateName("1", "123456789012345678901"));
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("1", null));
        String tooLong = new String(new char[51]).replace('\0', 'X');
        assertThrows(IllegalArgumentException.class, () -> service.updateDescription("1", tooLong));
        assertEquals("Name", service.getTask("1").getName());
        assertEquals("Details", service.getTask("1").getDescription());
    }

    @Test
    void rejectsUnknownAndNullIdsForEveryOperation() {
        TaskService service = new TaskService();
        for (String id : new String[] {"missing", null}) {
            assertThrows(IllegalArgumentException.class, () -> service.getTask(id));
            assertThrows(IllegalArgumentException.class, () -> service.deleteTask(id));
            assertThrows(IllegalArgumentException.class, () -> service.updateName(id, "New"));
            assertThrows(IllegalArgumentException.class, () -> service.updateDescription(id, "New"));
        }
    }
}
