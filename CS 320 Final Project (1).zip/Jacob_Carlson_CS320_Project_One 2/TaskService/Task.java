/** A task with a permanent ID and validated, editable details. */
public final class Task {
    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        this.taskId = validateText(taskId, 10, "Task ID");
        setName(name);
        setDescription(description);
    }

    private static String validateText(String value, int limit, String field) {
        if (value == null || value.length() > limit) {
            throw new IllegalArgumentException(field + " is null or too long");
        }
        return value;
    }

    public String getTaskId() { return taskId; }
    public String getName() { return name; }
    public String getDescription() { return description; }

    public void setName(String name) {
        this.name = validateText(name, 20, "Name");
    }

    public void setDescription(String description) {
        this.description = validateText(description, 50, "Description");
    }
}
