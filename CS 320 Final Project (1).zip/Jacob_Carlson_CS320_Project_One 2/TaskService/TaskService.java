import java.util.HashMap;
import java.util.Map;

/** Stores tasks in memory, using a unique ID for each stored task. */
public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task is null or ID already exists");
        }
        tasks.put(task.getTaskId(), task);
    }

    public Task getTask(String taskId) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID was not found");
        }
        return task;
    }

    public void deleteTask(String taskId) {
        getTask(taskId);
        tasks.remove(taskId);
    }

    public void updateName(String taskId, String name) {
        getTask(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getTask(taskId).setDescription(description);
    }
}
