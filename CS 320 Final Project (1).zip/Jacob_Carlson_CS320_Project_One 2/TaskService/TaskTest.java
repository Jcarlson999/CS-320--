import static org.junit.jupiter.api.Assertions.*;
import java.lang.reflect.Modifier;
import org.junit.jupiter.api.Test;

class TaskTest {
    private String text(int length) {
        return new String(new char[length]).replace('\0', 'X');
    }

    @Test
    void storesValidFieldsAtTheirLimits() {
        Task task = new Task(text(10), text(20), text(50));
        assertAll(() -> assertEquals(text(10), task.getTaskId()),
                  () -> assertEquals(text(20), task.getName()),
                  () -> assertEquals(text(50), task.getDescription()));
    }

    @Test
    void rejectsNullAndOverlongIds() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Details"));
        assertThrows(IllegalArgumentException.class, () -> new Task(text(11), "Name", "Details"));
    }

    @Test
    void rejectsNullAndOverlongNamesInConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Details"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", text(21), "Details"));
    }

    @Test
    void rejectsNullAndOverlongDescriptionsInConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", text(51)));
    }

    @Test
    void nameUpdateAcceptsLimitAndPreservesStateOnInvalidInput() {
        Task task = new Task("1", "Name", "Details");
        task.setName(text(20));
        assertEquals(text(20), task.getName());
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName(text(21)));
        assertAll(() -> assertEquals(text(20), task.getName()),
                  () -> assertEquals("Details", task.getDescription()),
                  () -> assertEquals("1", task.getTaskId()));
    }

    @Test
    void descriptionUpdateAcceptsLimitAndPreservesStateOnInvalidInput() {
        Task task = new Task("1", "Name", "Details");
        task.setDescription(text(50));
        assertEquals(text(50), task.getDescription());
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(text(51)));
        assertAll(() -> assertEquals(text(50), task.getDescription()),
                  () -> assertEquals("Name", task.getName()),
                  () -> assertEquals("1", task.getTaskId()));
    }

    @Test
    void idIsPrivateFinalAndHasNoSetter() throws Exception {
        int modifiers = Task.class.getDeclaredField("taskId").getModifiers();
        assertTrue(Modifier.isPrivate(modifiers));
        assertTrue(Modifier.isFinal(modifiers));
        assertThrows(NoSuchMethodException.class, () -> Task.class.getMethod("setTaskId", String.class));
    }
}
