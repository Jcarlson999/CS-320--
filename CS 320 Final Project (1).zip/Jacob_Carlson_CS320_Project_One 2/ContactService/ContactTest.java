/* Jacob Carlson
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactTest {
    private Contact sample() {
        return new Contact("123", "Jacob", "Carlson", "0123456789", "123 Main Street");
    }
    @Test
    void storesValidFieldsIncludingLeadingZeroPhone() {
        Contact c = sample();
        assertAll(() -> assertEquals("123", c.getContactId()),
                  () -> assertEquals("Jacob", c.getFirstName()),
                  () -> assertEquals("Carlson", c.getLastName()),
                  () -> assertEquals("0123456789", c.getPhone()),
                  () -> assertEquals("123 Main Street", c.getAddress()));
    }
    @Test
    void acceptsMaximumLengths() {
        Contact c = new Contact("1234567890", "ABCDEFGHIJ", "KLMNOPQRST",
                                "1234567890", "123456789012345678901234567890");
        assertEquals(10, c.getContactId().length());
        assertEquals(10, c.getFirstName().length());
        assertEquals(10, c.getLastName().length());
        assertEquals(30, c.getAddress().length());
    }
    @Test
    void idIsPrivateFinalAndHasNoSetter() throws Exception {
        int modifiers = Contact.class.getDeclaredField("contactId").getModifiers();
        assertTrue(java.lang.reflect.Modifier.isPrivate(modifiers));
        assertTrue(java.lang.reflect.Modifier.isFinal(modifiers));
        for (java.lang.reflect.Method method : Contact.class.getMethods()) {
            assertFalse(method.getName().equalsIgnoreCase("setContactId"));
        }
    }
    @Test
    void rejectsInvalidId0InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "Jacob", "Carlson", "0123456789", "123 Main Street"));
    }
    @Test
    void rejectsInvalidId1InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("XXXXXXXXXXX", "Jacob", "Carlson", "0123456789", "123 Main Street"));
    }
    @Test
    void rejectsInvalidFirstName0InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", null, "Carlson", "0123456789", "123 Main Street"));
    }
    @Test
    void rejectsInvalidFirstName0WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertEquals("Jacob", c.getFirstName());
    }
    @Test
    void rejectsInvalidFirstName1InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "XXXXXXXXXXX", "Carlson", "0123456789", "123 Main Street"));
    }
    @Test
    void rejectsInvalidFirstName1WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("XXXXXXXXXXX"));
        assertEquals("Jacob", c.getFirstName());
    }
    @Test
    void rejectsInvalidLastName0InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", null, "0123456789", "123 Main Street"));
    }
    @Test
    void rejectsInvalidLastName0WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertEquals("Carlson", c.getLastName());
    }
    @Test
    void rejectsInvalidLastName1InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "XXXXXXXXXXX", "0123456789", "123 Main Street"));
    }
    @Test
    void rejectsInvalidLastName1WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("XXXXXXXXXXX"));
        assertEquals("Carlson", c.getLastName());
    }
    @Test
    void rejectsInvalidPhone0InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", null, "123 Main Street"));
    }
    @Test
    void rejectsInvalidPhone0WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setPhone(null));
        assertEquals("0123456789", c.getPhone());
    }
    @Test
    void rejectsInvalidPhone1InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "XXXXXXXXXXX", "123 Main Street"));
    }
    @Test
    void rejectsInvalidPhone1WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("XXXXXXXXXXX"));
        assertEquals("0123456789", c.getPhone());
    }
    @Test
    void rejectsInvalidPhone2InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "123456789", "123 Main Street"));
    }
    @Test
    void rejectsInvalidPhone2WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123456789"));
        assertEquals("0123456789", c.getPhone());
    }
    @Test
    void rejectsInvalidPhone3InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "12345a7890", "123 Main Street"));
    }
    @Test
    void rejectsInvalidPhone3WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("12345a7890"));
        assertEquals("0123456789", c.getPhone());
    }
    @Test
    void rejectsInvalidPhone4InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "123 567890", "123 Main Street"));
    }
    @Test
    void rejectsInvalidPhone4WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123 567890"));
        assertEquals("0123456789", c.getPhone());
    }
    @Test
    void rejectsInvalidPhone5InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "", "123 Main Street"));
    }
    @Test
    void rejectsInvalidPhone5WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setPhone(""));
        assertEquals("0123456789", c.getPhone());
    }
    @Test
    void rejectsInvalidPhone6InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "１２３４５６７８９０", "123 Main Street"));
    }
    @Test
    void rejectsInvalidPhone6WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("１２３４５６７８９０"));
        assertEquals("0123456789", c.getPhone());
    }
    @Test
    void rejectsInvalidAddress0InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "0123456789", null));
    }
    @Test
    void rejectsInvalidAddress0WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
        assertEquals("123 Main Street", c.getAddress());
    }
    @Test
    void rejectsInvalidAddress1InConstructor() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "Jacob", "Carlson", "0123456789", "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"));
    }
    @Test
    void rejectsInvalidAddress1WithoutChangingExistingValue() {
        Contact c = sample();
        assertThrows(IllegalArgumentException.class, () -> c.setAddress("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"));
        assertEquals("123 Main Street", c.getAddress());
    }
    @Test
    void validEditsKeepIdUnchanged() {
        Contact c = sample();
        c.setFirstName("ABCDEFGHIJ"); c.setLastName("KLMNOPQRST");
        c.setPhone("9876543210"); c.setAddress("123456789012345678901234567890");
        assertAll(() -> assertEquals("123", c.getContactId()),
                  () -> assertEquals("ABCDEFGHIJ", c.getFirstName()),
                  () -> assertEquals("KLMNOPQRST", c.getLastName()),
                  () -> assertEquals("9876543210", c.getPhone()),
                  () -> assertEquals(30, c.getAddress().length()));
    }
}
