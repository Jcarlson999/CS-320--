/* Jacob Carlson
import java.util.HashMap;
import java.util.Map;

/** Stores contacts in memory and locates each contact by its unique ID. */
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    public void addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact is null or ID already exists");
        }
        contacts.put(contact.getContactId(), contact);
    }

    // Missing IDs are rejected consistently for lookup, deletion, and updates.
    public Contact getContact(String contactId) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID was not found");
        }
        return contact;
    }
    public void deleteContact(String contactId) {
        getContact(contactId);
        contacts.remove(contactId);
    }
    public void updateFirstName(String contactId, String value) {
        getContact(contactId).setFirstName(value);
    }
    public void updateLastName(String contactId, String value) {
        getContact(contactId).setLastName(value);
    }
    public void updatePhone(String contactId, String value) {
        getContact(contactId).setPhone(value);
    }
    public void updateAddress(String contactId, String value) {
        getContact(contactId).setAddress(value);
    }
}
