/* Jacob Carlson
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
    private Contact contact(String id) {
        return new Contact(id, "Jacob", "Carlson", "0123456789", "123 Main Street");
    }
    @Test
    void addsDistinctIdsAndRejectsDuplicateWithoutReplacingOriginal() {
        ContactService service = new ContactService();
        Contact first = contact("1");
        Contact second = contact("2");
        service.addContact(first); service.addContact(second);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(contact("1")));
        assertSame(first, service.getContact("1"));
        assertSame(second, service.getContact("2"));
    }
    @Test
    void rejectsNullContact() {
        assertThrows(IllegalArgumentException.class, () -> new ContactService().addContact(null));
    }
    @Test
    void deletesOnlyRequestedContactAndAllowsIdReuse() {
        ContactService service = new ContactService();
        service.addContact(contact("1")); service.addContact(contact("2"));
        service.deleteContact("1");
        assertThrows(IllegalArgumentException.class, () -> service.getContact("1"));
        assertEquals("2", service.getContact("2").getContactId());
        service.addContact(contact("1"));
        assertEquals("1", service.getContact("1").getContactId());
    }
    @Test
    void missingAndNullIdsAreRejected() {
        ContactService service = new ContactService();
        for (String id : new String[] {"missing", null}) {
            assertThrows(IllegalArgumentException.class, () -> service.getContact(id));
            assertThrows(IllegalArgumentException.class, () -> service.deleteContact(id));
            assertThrows(IllegalArgumentException.class, () -> service.updateFirstName(id, "John"));
            assertThrows(IllegalArgumentException.class, () -> service.updateLastName(id, "Smith"));
            assertThrows(IllegalArgumentException.class, () -> service.updatePhone(id, "9876543210"));
            assertThrows(IllegalArgumentException.class, () -> service.updateAddress(id, "New address"));
        }
    }
    @Test
    void updatesFirstNameByIdWithoutChangingOtherContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1")); service.addContact(contact("2"));
        service.updateFirstName("1", "ABCDEFGHIJ");
        assertEquals("ABCDEFGHIJ", service.getContact("1").getFirstName());
        assertEquals("Jacob", service.getContact("2").getFirstName());
        assertEquals("1", service.getContact("1").getContactId());
    }
    @Test
    void rejectsInvalidFirstNameUpdateAndPreservesContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1"));
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1", "ABCDEFGHIJK"));
        assertEquals("Jacob", service.getContact("1").getFirstName());
    }
    @Test
    void updatesLastNameByIdWithoutChangingOtherContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1")); service.addContact(contact("2"));
        service.updateLastName("1", "KLMNOPQRST");
        assertEquals("KLMNOPQRST", service.getContact("1").getLastName());
        assertEquals("Carlson", service.getContact("2").getLastName());
        assertEquals("1", service.getContact("1").getContactId());
    }
    @Test
    void rejectsInvalidLastNameUpdateAndPreservesContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1", "KLMNOPQRSTU"));
        assertEquals("Carlson", service.getContact("1").getLastName());
    }
    @Test
    void updatesPhoneByIdWithoutChangingOtherContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1")); service.addContact(contact("2"));
        service.updatePhone("1", "9876543210");
        assertEquals("9876543210", service.getContact("1").getPhone());
        assertEquals("0123456789", service.getContact("2").getPhone());
        assertEquals("1", service.getContact("1").getContactId());
    }
    @Test
    void rejectsInvalidPhoneUpdateAndPreservesContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("1", "12345a7890"));
        assertEquals("0123456789", service.getContact("1").getPhone());
    }
    @Test
    void updatesAddressByIdWithoutChangingOtherContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1")); service.addContact(contact("2"));
        service.updateAddress("1", "123456789012345678901234567890");
        assertEquals("123456789012345678901234567890", service.getContact("1").getAddress());
        assertEquals("123 Main Street", service.getContact("2").getAddress());
        assertEquals("1", service.getContact("1").getContactId());
    }
    @Test
    void rejectsInvalidAddressUpdateAndPreservesContact() {
        ContactService service = new ContactService();
        service.addContact(contact("1"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1", "1234567890123456789012345678901"));
        assertEquals("123 Main Street", service.getContact("1").getAddress());
    }
}
