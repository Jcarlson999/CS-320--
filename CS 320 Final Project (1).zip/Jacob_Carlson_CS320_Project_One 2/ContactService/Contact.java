/* Jacob Carlson
/** A contact with a permanent ID and validated, editable details. */
public final class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName,
                   String phone, String address) {
        this.contactId = validateText(contactId, 10, "Contact ID");
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    // Validate before assignment so rejected edits preserve the previous value.
    private static String validateText(String value, int limit, String field) {
        if (value == null || value.length() > limit) {
            throw new IllegalArgumentException(field + " is null or too long");
        }
        return value;
    }

    public String getContactId() { return contactId; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }

    public void setFirstName(String value) {
        firstName = validateText(value, 10, "First name");
    }
    public void setLastName(String value) {
        lastName = validateText(value, 10, "Last name");
    }
    public void setPhone(String value) {
        if (value == null || !value.matches("[0-9]{10}")) {
            throw new IllegalArgumentException("Phone must contain exactly 10 digits");
        }
        phone = value;
    }
    public void setAddress(String value) {
        address = validateText(value, 30, "Address");
    }
}
